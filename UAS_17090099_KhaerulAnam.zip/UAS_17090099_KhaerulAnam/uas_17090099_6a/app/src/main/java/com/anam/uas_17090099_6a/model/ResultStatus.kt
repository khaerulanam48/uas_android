package com.anam.uas_17090099_6a.model

class ResultStatus {
    val pesan : String? = null
    val status : Int? = null
}